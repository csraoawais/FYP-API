package com.cui.edu.hostel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CuiHostelApplicationTests {

	@Test
	void contextLoads() {
	}

}
