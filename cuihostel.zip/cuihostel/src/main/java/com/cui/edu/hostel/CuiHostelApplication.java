package com.cui.edu.hostel;

import com.cui.edu.hostel.dbmigrations.DefaultDataSeeding;
import com.github.mongobee.exception.MongobeeException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.Bean;

import com.github.mongobee.Mongobee;

@SpringBootApplication
public class CuiHostelApplication extends SpringBootServletInitializer {

	@Value("${spring.data.mongodb.uri}")
	 private String mongoDbUri ; 
	    
	 @Value("${spring.data.mongodb.database}")
	 private String dataBaseName;
	
	public static void main(String[] args) {
		SpringApplication.run(CuiHostelApplication.class, args);
	}

	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		return application.sources(CuiHostelApplication.class);
	}

	
	 @Bean
	    public Mongobee mongobee(){
	    	Mongobee runner = new Mongobee(mongoDbUri);
	    	runner.setDbName(dataBaseName);            	
	    	runner.setChangeLogsScanPackage(DefaultDataSeeding.class.getPackage().getName());
	      return runner;
	    }
	
}
