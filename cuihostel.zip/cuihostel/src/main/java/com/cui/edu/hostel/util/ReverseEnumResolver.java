package com.cui.edu.hostel.util;

import java.util.Arrays;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * Helps reverse resolving of enums from any value back to enum instance.
 * Resolver uses provided function that obtains value from enum instance.
 *
 * @param <T> type of an enum
 * @param <Y> type of a value
 *
 * Implementation reference https://virgo47.wordpress.com/2014/08/20/converting-java-enums-to-values-and-back-with-java-8/
 */
@SuppressWarnings("rawtypes")
public final class ReverseEnumResolver<T extends Enum, Y> {

    ///
    /// Members
    ///

    private final Map<Y, T> valueMap;

    ///
    /// Methods
    ///

    public ReverseEnumResolver(Class<T> enumClass, Function<T, Y> toValueFunction) {
        valueMap = Arrays.stream(enumClass.getEnumConstants()).collect(Collectors.toMap(toValueFunction, t -> t));
    }

    public Optional<T> get(Y value) {
        return Optional.ofNullable(Objects.isNull(value) ? null : valueMap.get(value));
    }
}
