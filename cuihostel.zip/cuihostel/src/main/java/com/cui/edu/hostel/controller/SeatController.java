package com.cui.edu.hostel.controller;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cui.edu.hostel.bean.SeatStates;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.cui.edu.hostel.bean.Seat;
import com.cui.edu.hostel.config.SwaggerConfig;
import com.cui.edu.hostel.service.SeatService;
import com.cui.edu.hostel.util.GeneralResponseMessage;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping(value = "/v1/seat")
@Api(tags = { SwaggerConfig.Seat })
public class SeatController implements CrossOriginEnabled{

	@Autowired
	SeatService seatService;

	@RequestMapping(path = "/addSeat",produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
		@ApiResponses(value = {
	  		@ApiResponse(code = HttpServletResponse.SC_OK, message = GeneralResponseMessage.SUCCESS,response = Seat.class),
	  		@ApiResponse(code = HttpServletResponse.SC_NOT_FOUND, message = GeneralResponseMessage.NOT_FOUND),
	  		@ApiResponse(code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = GeneralResponseMessage.INTERNAL_SERVER_ERROR)
	  })
		public Seat addSeat(@RequestParam(value = "studentId", required = true) String studentId,
							@RequestParam(value = "studentName", required = true) String studentName) {
		  Seat seat = Seat.builder().studentId(studentId).studentName(studentName).isReserved(true)
				  .reservationDate(new Date()).seatState(SeatStates.PENDINGCHALLAN).build();
			return this.seatService.addSeat(seat);
		}

	@RequestMapping(path = "/getAllReservedSeats",produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
	@ApiResponses(value = {
  		@ApiResponse(code = HttpServletResponse.SC_OK, message = GeneralResponseMessage.SUCCESS,response = Seat.class),
  		@ApiResponse(code = HttpServletResponse.SC_NOT_FOUND, message = GeneralResponseMessage.NOT_FOUND),
  		@ApiResponse(code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = GeneralResponseMessage.INTERNAL_SERVER_ERROR)
  })
	public List<Seat> getAllReservedSeats() {
	 
		return this.seatService.getAllReserved();
	}
	
	@RequestMapping(path = "/getAllReservedSeatsCount",produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
	@ApiResponses(value = {
  		@ApiResponse(code = HttpServletResponse.SC_OK, message = GeneralResponseMessage.SUCCESS, response = Long.class),
  		@ApiResponse(code = HttpServletResponse.SC_NOT_FOUND, message = GeneralResponseMessage.NOT_FOUND),
  		@ApiResponse(code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = GeneralResponseMessage.INTERNAL_SERVER_ERROR)
  })
	public Long getAllReservedSeatsCount() {
		return this.seatService.getAllCountReserved();
	}
	
	
	@RequestMapping(path = "/updateSeatReservation",produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.PATCH)
	@ApiResponses(value = {
  		@ApiResponse(code = HttpServletResponse.SC_OK, message = GeneralResponseMessage.SUCCESS, response = Seat.class),
  		@ApiResponse(code = HttpServletResponse.SC_NOT_FOUND, message = GeneralResponseMessage.NOT_FOUND),
  		@ApiResponse(code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = GeneralResponseMessage.INTERNAL_SERVER_ERROR)
  })
	public Seat updateSeatReservation(@RequestParam(value = "seatId", required = true) String id,
			@RequestParam(value = "seatState", required = true) SeatStates seatState,
			@RequestParam(value = "studentId", required = false) String studentId,
			@RequestParam(value = "studentName", required = false) String studentName,
			@RequestParam(value = "chalanFile", required = false) MultipartFile chalanFile
			) {
		
		if(seatState.equals(SeatStates.PENDINGAPPROVAL) && chalanFile != null) {
			return this.seatService.uploadChalan(id, seatState, chalanFile);
		}
		return this.seatService.updateSeatReservation(id, seatState);
	}

	@RequestMapping(value="/download-challan",  method=RequestMethod.GET)
	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, message = GeneralResponseMessage.SUCCESS),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, message = GeneralResponseMessage.BAD_REQUEST),
			@ApiResponse(code = HttpServletResponse.SC_NOT_FOUND, message = GeneralResponseMessage.NOT_FOUND),
			@ApiResponse(code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = GeneralResponseMessage.INTERNAL_SERVER_ERROR)
	})
	public void downloadChalan(HttpServletResponse response, @RequestParam(value = "studentName", required = true) String studentName, HttpServletRequest request) throws Exception
	{
		try {

			String contentType = "application/octet-stream";

			byte[] contents=this.seatService.getGeneratedChallanFile(studentName);

			response.setContentType(String.valueOf(MediaType.APPLICATION_PDF));
			response.addHeader("Content-Disposition",
					"attachment; filename=\""+"Challan"+"\"");
			response.setHeader("Content-Length", String.valueOf(contents.length) );
			response.getOutputStream().write(contents);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}


}
