package com.cui.edu.hostel.scheduler;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import com.cui.edu.hostel.dao.SeatDao;
import org.joda.time.DateTime;
import org.joda.time.Hours;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.cui.edu.hostel.bean.Seat;
import com.cui.edu.hostel.bean.SeatStates;
import com.cui.edu.hostel.service.SeatService;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class SeatStatusScheduler {
	
	@Autowired
	SeatService seatService;

	@Autowired
	SeatDao seatDao;
	
	@Scheduled(cron = "${eval.cron}")
	public void execute() {
		log.info("---Seat Status Job started @ " + new Date()+"---");
		List<SeatStates> seatStates=new ArrayList<>();
		seatStates.add(SeatStates.PENDINGCHALLAN);
		try {
			List<Seat> approvalPendingSeats = this.seatService.getAllBySeatStates(seatStates);
			if(!CollectionUtils.isEmpty(approvalPendingSeats)) {
				approvalPendingSeats.forEach(pendingSeat -> {
					if(pendingSeat.getReservationDate() != null){
						Date reservationDate = pendingSeat.getReservationDate();
						Date currentDate = Calendar.getInstance().getTime();

						DateTime startTime = new DateTime(reservationDate);
						DateTime endTime = new DateTime(currentDate);
						Hours hours = Hours.hoursBetween(startTime, endTime);
						if(hours.getHours() >= 24){
							pendingSeat.setReservationDate(null);
							pendingSeat.setStudentId(null);
							pendingSeat.setChallanUploaded(false);
							pendingSeat.setStudentName(null);
							pendingSeat.setSeatState(SeatStates.WAITING);
							this.seatDao.save(pendingSeat);
						}
					}
				});
			}
			
		} catch (Exception e) {
			log.error("Error while running seat scheduler due to reason ({})", e.getMessage(), e);
		}
	}

}
