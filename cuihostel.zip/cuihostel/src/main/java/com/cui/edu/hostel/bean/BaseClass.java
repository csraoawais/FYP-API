package com.cui.edu.hostel.bean;

import java.util.Date;

import lombok.Data;

@Data
public class BaseClass {

	public String id;
	
	public Date createDate = new Date();
	
}
