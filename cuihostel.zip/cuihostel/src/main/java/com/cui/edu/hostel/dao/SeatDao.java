package com.cui.edu.hostel.dao;

import java.util.Collection;
import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.cui.edu.hostel.bean.Seat;
import com.cui.edu.hostel.bean.SeatStates;

@Repository
public interface SeatDao extends MongoRepository<Seat,String> {
	
	List<Seat> getAllByIsReserved(boolean isReserved);
	Long countByIsReserved(boolean IsReserved);
	List<Seat> findAllBySeatStateIn(Collection<SeatStates> seatState);
}
