package com.cui.edu.hostel.bean;

import java.util.Date;

import lombok.Builder;

import org.bson.types.ObjectId;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Document(collection = "seat")
@EqualsAndHashCode(callSuper=true)
@Data
@Builder
public class Seat extends BaseClass{
	String studentId;
	String studentName;
	String seatNo;
	@Builder.Default
	boolean isReserved;
	@Builder.Default
	boolean isChallanUploaded = false;
	Date reservationDate;
	SeatStates seatState;
	private ObjectId challanId;
}
