package com.cui.edu.hostel.util;

import lombok.experimental.UtilityClass;

@UtilityClass
public class GeneralResponseMessage {
	public final String SUCCESS = "Success";
	public final String NOT_FOUND = "Not Found";
	public final String BAD_REQUEST = "Bad Request";
	public final String INTERNAL_SERVER_ERROR = "Internal Server Error";
}
