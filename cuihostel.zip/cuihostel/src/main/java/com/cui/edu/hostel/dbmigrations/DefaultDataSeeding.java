package com.cui.edu.hostel.dbmigrations;

import com.github.mongobee.changeset.ChangeLog;
import com.github.mongobee.changeset.ChangeSet;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;
import org.springframework.util.ResourceUtils;

import java.io.File;
import java.nio.charset.Charset;
import java.util.List;
import org.apache.commons.io.FileUtils;

@ChangeLog
public class DefaultDataSeeding {
	
	@ChangeSet(order = "002", id = "loadDefaultCollections", author = "@awais")
	public void loadCollections(MongoDatabase db) {
		loadCollection(db, "seat.json");
	}

	private void loadCollection(MongoDatabase db, String filename) {
		try {
			ClassLoader classLoader = getClass().getClassLoader();
			File file = ResourceUtils.getFile("classpath:seat.json");
//					new File(classLoader.getResource(filename).getFile());
			String string = FileUtils.readFileToString(file, Charset.defaultCharset());
			Document doc = Document.parse(string);
			if(doc.containsKey("collection")) {
				String collectionName = doc.getString("collection");
				MongoCollection<Document> collection = db.getCollection(collectionName);
				@SuppressWarnings("unchecked")
				List<Document> values = (List<Document>) doc.get("data");
				for (Document value : values) {
					collection.insertOne(value);
				}
			} else {
				throw new RuntimeException("Invalid File Format: Collection name is missing " + filename);
			}
		} catch (Exception e) {
			throw new RuntimeException("Error reading file: " + filename, e);
		}
	}
}
