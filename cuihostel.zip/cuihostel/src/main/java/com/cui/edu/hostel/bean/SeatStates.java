package com.cui.edu.hostel.bean;

import com.cui.edu.hostel.util.ReverseEnumResolver;
import org.springframework.lang.Nullable;

import java.util.Optional;

public enum SeatStates {
    ALL,
    WAITING,
    PENDINGCHALLAN,
    PENDINGAPPROVAL,
    APPROVED;

    private final String value;

    private static final ReverseEnumResolver<SeatStates, String> valueResolver =
            new ReverseEnumResolver<>(SeatStates.class, SeatStates::value);

    SeatStates() {
        this.value = this.name();
    }

    public String value() {
        return this.value;
    }

    public static Optional<SeatStates> fromString(@Nullable String mayBeSeatState) {
        return valueResolver.get(mayBeSeatState);


    }
}
