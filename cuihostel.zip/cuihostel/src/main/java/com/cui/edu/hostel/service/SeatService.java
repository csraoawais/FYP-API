package com.cui.edu.hostel.service;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import com.mongodb.client.gridfs.model.GridFSFile;
import org.apache.commons.io.IOUtils;
import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.cui.edu.hostel.bean.Seat;
import com.cui.edu.hostel.bean.SeatStates;
import com.cui.edu.hostel.dao.SeatDao;

@Service
public class SeatService {

	final SeatDao seatDao;
	
	final MongoFileService mongoFileService;

	@Autowired
	public SeatService(SeatDao seatDao, MongoFileService mongoFileService) {
		this.seatDao = seatDao;
		this.mongoFileService = mongoFileService;
	}
	
 
	public Seat addSeat(Seat seat) {
		return this.seatDao.save(seat);
	}
	
	public List<Seat> getAllReserved(){
		List<SeatStates> seatState = new ArrayList<>();
		seatState.add(SeatStates.PENDINGAPPROVAL);
		seatState.add(SeatStates.PENDINGCHALLAN);
		seatState.add(SeatStates.APPROVED);
		return this.seatDao.findAllBySeatStateIn(seatState);
	}
	
	public List<Seat> getAllBySeatStates(List<SeatStates> seatStates){
		return this.seatDao.findAllBySeatStateIn(seatStates);
	}
	
	public Long getAllCountReserved(){
		return this.seatDao.countByIsReserved(true);
	}
	
	public Seat uploadChalan(String id, SeatStates seatState, MultipartFile file) {
		Optional<Seat> mayBeSeat= this.seatDao.findById(id);
		Seat seat = null;
		
		if(mayBeSeat.isPresent()) {
			seat = mayBeSeat.get();
		}
		
		if(seat != null && seat.getSeatState().equals(SeatStates.PENDINGCHALLAN) && seat.isReserved()) {
			ObjectId challanId = this.mongoFileService.saveFile(file);
			if(challanId != null) {
				seat.setChallanId(challanId);
				seat.setChallanUploaded(true);
			}
			this.seatDao.save(seat);
		}
		return seat;
	}
	
	public Seat updateSeatReservation(String id, SeatStates seatState) {
		Optional<Seat> mayBeSeat= this.seatDao.findById(id);
		Seat seat = null;
		
		if(mayBeSeat.isPresent()) {
			seat = mayBeSeat.get();
		}
		
		if(seat != null) {
			seat.setSeatState(seatState);
			if(seatState.equals(SeatStates.PENDINGAPPROVAL) || seatState.equals(SeatStates.PENDINGCHALLAN) || seatState.equals(SeatStates.APPROVED)) {
				seat.setReserved(true);
				if(seat.getReservationDate() == null) {
					seat.setReservationDate(new Date());
				}
				if(seatState.equals(SeatStates.PENDINGAPPROVAL)) {
					seat.setChallanUploaded(true);
				}
			} else  {
				seat.setReserved(false);
				seat.setReservationDate(null);
			}
			this.seatDao.save(seat);
		
		}
		return seat;
	}

	public byte[] getGeneratedChallanFile(String studentName){
		return this.mongoFileService.createChallanFile(studentName);
	}
}
