package com.cui.edu.hostel.controller;

import org.springframework.web.bind.annotation.CrossOrigin;

@CrossOrigin(origins = "*")
public interface CrossOriginEnabled {

}
